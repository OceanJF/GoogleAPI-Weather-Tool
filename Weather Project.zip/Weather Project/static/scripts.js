document.getElementById('search-btn').addEventListener('click', function() {
    // Get the city name from the input and fetch weather data
    const city = document.getElementById('city-input').value;
    if (city) {
        fetchWeatherData(city);
    }
});

function fetchWeatherData(city) {
    // Fetch current weather data from OpenWeatherMap API
    const apiKey = 'af987ff7af46908e0cf662ea4768cda3'; // Ensure this matches your actual API key
    const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

    console.log(`Fetching weather data for: ${city}`);  // Debugging statement
    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            console.log('Weather data:', data);  // Debugging statement
            if (data.cod === 200) {
                updateWeatherUI(data);
            } else {
                alert(`Error: ${data.message}`);
            }
        })
        .catch(error => console.error('Error fetching weather data:', error));
}

function updateWeatherUI(data) {
    // Update the UI with the fetched weather data
    console.log('Updating weather UI with data:', data);  // Debugging statement
    document.getElementById('current-weather-icon').src = `https://openweathermap.org/img/wn/${data.weather[0].icon}@2x.png`;
    document.getElementById('current-weather-title').textContent = `Current Weather in ${data.name}`;
    document.getElementById('current-weather-temp').textContent = `Temperature: ${Math.round(data.main.temp)}°C`;
    document.getElementById('current-weather-humidity').textContent = `Humidity: ${data.main.humidity}%`;
    document.getElementById('current-weather-wind').textContent = `Wind Speed: ${Math.round(data.wind.speed)} m/s`;
}

function displayForecast(data) {
    // Display the 7-day forecast data
    const forecastSection = document.getElementById('forecast');
    forecastSection.innerHTML = '<h2>7-Day Forecast</h2>';
    data.list.forEach(day => {
        const tempCelsius = Math.round(day.temp.day - 273.15); // Convert from Kelvin to Celsius and round
        const iconUrl = `http://openweathermap.org/img/wn/${day.weather[0].icon}@2x.png`; // Get weather icon URL
        forecastSection.innerHTML += `
            <div class="forecast-day">
                <h3>${new Date(day.dt * 1000).toLocaleDateString()}</h3>
                <img src="${iconUrl}" alt="${day.weather[0].description}">
                <p>Temperature: ${tempCelsius}°C</p>
                <p>${day.weather[0].description}</p>
            </div>
        `;
    });
}