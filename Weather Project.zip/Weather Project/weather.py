from flask import Flask, request, jsonify, render_template
import requests
import os
from flask_caching import Cache

# Initialize Flask app
app = Flask(__name__)

# Configure cache
cache = Cache(app, config={'CACHE_TYPE': 'simple'})

# Set API key and base URL for OpenWeatherMap API
API_KEY = 'af987ff7af46908e0cf662ea4768cda3'
BASE_URL = 'http://api.openweathermap.org/data/2.5/'

@app.route('/')
def index():
    # Render the main page
    return render_template('index.html')

@app.route('/current_weather', methods=['GET'])
@cache.cached(timeout=300)
def get_current_weather():
    # Get the city name from the request
    city = request.args.get('city')
    if not city:
        return jsonify({'error': 'City name is required'}), 400

    try:
        # Fetch current weather data from OpenWeatherMap API
        print(f"Fetching current weather for: {city}")  # Debugging statement
        response = requests.get(f'{BASE_URL}weather', params={'q': city, 'appid': API_KEY})
        response.raise_for_status()
        data = response.json()
        print('Current weather data:', data)  # Debugging statement
        if data.get('cod') != 200:
            return jsonify({'error': data.get('message', 'City not found')}), 404
        return jsonify(data)
    except requests.exceptions.RequestException as e:
        print(f"Error fetching current weather: {e}")  # Debugging statement
        return jsonify({'error': str(e)}), 500

@app.route('/forecast', methods=['GET'])
@cache.cached(timeout=300)
def get_forecast():
    # Get the city name from the request
    city = request.args.get('city')
    if not city:
        return jsonify({'error': 'City name is required'}), 400

    try:
        # Fetch 7-day forecast data from OpenWeatherMap API
        print(f"Fetching forecast for: {city}")  # Debugging statement
        response = requests.get(f'{BASE_URL}forecast', params={'q': city, 'cnt': 7, 'appid': API_KEY})
        response.raise_for_status()
        data = response.json()
        print('Forecast data:', data)  # Debugging statement
        if data.get('cod') != '200':
            return jsonify({'error': data.get('message', 'City not found')}), 404
        return jsonify(data)
    except requests.exceptions.RequestException as e:
        print(f"Error fetching forecast: {e}")  # Debugging statement
        return jsonify({'error': str(e)}), 500

@app.route('/background_color', methods=['GET'])
def get_background_color():
    # Return the background color as a JSON response
    return jsonify({'color': '#00c6ff'})  # Example color, you can change it dynamically

if __name__ == '__main__':
    # Run the Flask app in debug mode
    app.run(debug=True)
